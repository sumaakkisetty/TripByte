import SwiftUI

// MARK: - Models (Unchanged)
struct Trip: Identifiable {
    let id = UUID()
    var name: String
    var startDate: Date
    var endDate: Date
    var days: [Day] = []
    var checklistItems: [ChecklistItem] = []
    var expenses: [Expense] = []
}

struct City: Identifiable {
    let id = UUID()
    let name: String
    let nearbyPlaces: [TouristPlace]
    let imageName: String
}

struct TouristPlace: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let description: String
    
    static func == (lhs: TouristPlace, rhs: TouristPlace) -> Bool {
        return lhs.id == rhs.id
    }
}

struct Day: Identifiable {
    let id: Int
    var place: String
    var time: Date
    var notes: String
}

struct ChecklistItem: Identifiable {
    let id = UUID()
    var name: String
    var isChecked: Bool
}

struct Expense: Identifiable {
    let id = UUID()
    var amount: Double
    var category: String
    var date: Date
}

// MARK: - Design System (Unchanged)
struct DesignSystem {
    static let primaryColor = Color(hex: "1A73E8") // Deep blue for icons and buttons
    static let backgroundColor = Color(hex: "F5F5F5") // Off-white for other screens
    static let travelBackground = LinearGradient(
        gradient: Gradient(colors: [Color(hex: "87CEEB"), Color(hex: "E0F6FF")]), // Sky blue to light blue
        startPoint: .top,
        endPoint: .bottom
    )
    static let skyBlue = Color(hex: "87CEEB") // Sky blue for accents
    static let cardGradient = LinearGradient(
        gradient: Gradient(colors: [Color.white.opacity(0.95), Color.white.opacity(0.9)]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    static let shadowColor = Color.black.opacity(0.1)
}

// MARK: - Home View (Unchanged)
struct HomeView: View {
    @State private var trips: [Trip] = [
        Trip(name: "Paris Getaway", startDate: Date(), endDate: Date().addingTimeInterval(86400 * 7))
    ]
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack {
            DesignSystem.backgroundColor.edgesIgnoringSafeArea(.all)
            TabView(selection: $selectedTab) {
                TripsView(trips: $trips)
                    .tabItem {
                        Label("Trips", systemImage: "suitcase.fill")
                    }
                    .tag(0)
                
                ExploreView()
                    .tabItem {
                        Label("Explore", systemImage: "globe")
                    }
                    .tag(1)
            }
            .accentColor(DesignSystem.primaryColor)
            .animation(.easeInOut(duration: 0.3), value: selectedTab)
        }
    }
}

// MARK: - Trips View (Animated Clouds and Airplanes Moving Up and Down Within Screen)
struct TripsView: View {
    @Binding var trips: [Trip]
    @State private var showingAddTrip = false
    @State private var selectedTripForPlace: Trip?
    @State private var cloud1Offset: CGFloat = -60 // Start near top of screen
    @State private var cloud2Offset: CGFloat = 60 // Start near bottom of screen
    @State private var airplane1Offset: CGFloat = -80 // Start near top of screen
    @State private var airplane2Offset: CGFloat = 80 // Start near bottom of screen
    
    var body: some View {
        NavigationView {
            ZStack {
                // Sky blue to light blue gradient background
                DesignSystem.travelBackground
                    .edgesIgnoringSafeArea(.all)
                    .overlay(
                        // Animated cloud 1 (moving up and down within screen)
                        Image(systemName: "cloud.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 60)
                            .foregroundColor(.white.opacity(0.4))
                            .offset(y: cloud1Offset)
                            .position(x: UIScreen.main.bounds.width / 4, y: UIScreen.main.bounds.height / 2) // Center horizontally
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 8).repeatForever(autoreverses: true)) {
                                    cloud1Offset = 60 // Move from -60 (top) to 60 (bottom) within screen
                                }
                            }
                    )
                    .overlay(
                        // Animated cloud 2 (moving up and down within screen)
                        Image(systemName: "cloud.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 140, height: 70)
                            .foregroundColor(.white.opacity(0.4))
                            .offset(y: cloud2Offset)
                            .position(x: 3 * UIScreen.main.bounds.width / 4, y: UIScreen.main.bounds.height / 2) // Center horizontally, offset right
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 10).repeatForever(autoreverses: true)) {
                                    cloud2Offset = -60 // Move from 60 (bottom) to -60 (top) within screen
                                }
                            }
                    )
                    .overlay(
                        // Animated airplane 1 (moving up and down within screen)
                        Image(systemName: "airplane")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray.opacity(0.2))
                            .rotationEffect(.degrees(45))
                            .offset(y: airplane1Offset)
                            .position(x: UIScreen.main.bounds.width / 3, y: UIScreen.main.bounds.height / 2) // Center horizontally, offset left
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 6).repeatForever(autoreverses: true)) {
                                    airplane1Offset = 80 // Move from -80 (top) to 80 (bottom) within screen
                                }
                            }
                    )
                    .overlay(
                        // Animated airplane 2 (moving up and down within screen)
                        Image(systemName: "airplane")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray.opacity(0.2))
                            .rotationEffect(.degrees(-45))
                            .offset(y: airplane2Offset)
                            .position(x: 2 * UIScreen.main.bounds.width / 3, y: UIScreen.main.bounds.height / 2) // Center horizontally, offset right
                            .onAppear {
                                withAnimation(Animation.easeInOut(duration: 7).repeatForever(autoreverses: true)) {
                                    airplane2Offset = -80 // Move from 80 (bottom) to -80 (top) within screen
                                }
                            }
                    )
                
                // Content layer (cards and buttons) with elevation
                ScrollView {
                    LazyVStack(spacing: 8) {
                        Text("Your Trips")
                            .font(.system(.title2, design: .rounded, weight: .bold))
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
                            .padding(.top, 20)
                            .padding(.horizontal, 20)
                        
                        ForEach(trips.indices, id: \.self) { index in
                            NavigationLink(destination: TripDetailView(trip: $trips[index], onAddPlace: { place in
                                selectedTripForPlace = trips[index]
                            })) {
                                TripCard(trip: trips[index])
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.horizontal, 16)
                        
                        Button(action: { showingAddTrip = true }) {
                            HStack {
                                Image(systemName: "plus")
                                    .font(.system(size: 16))
                                    .foregroundColor(.white)
                                Text("Create New Trip")
                                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 16)
                            .frame(maxWidth: .infinity)
                            .background(DesignSystem.primaryColor)
                            .cornerRadius(14)
                            .shadow(color: DesignSystem.shadowColor, radius: 6, x: 0, y: 4)
                            .padding(.horizontal, 16)
                            .padding(.bottom, 20)
                        }
                    }
                }
                .zIndex(1) // Ensure content is above background
            }
            .navigationTitle("Trips")
            .navigationBarTitleDisplayMode(.large)
            .foregroundColor(.white) // Ensure navigation title is white
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Trips")
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
                }
            }
            .sheet(isPresented: $showingAddTrip) {
                AddTripView(trips: $trips)
            }
        }
    }
}

// MARK: - Trip Card (Unchanged)
struct TripCard: View {
    let trip: Trip
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "suitcase")
                .font(.system(size: 20))
                .foregroundColor(.white)
                .frame(width: 24, height: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(trip.name)
                    .font(.system(.body, design: .rounded, weight: .semibold))
                    .foregroundColor(.primary)
                Text("\(trip.startDate, style: .date) - \(trip.endDate, style: .date)")
                    .font(.system(.caption, design: .rounded))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(DesignSystem.primaryColor)
                .font(.system(size: 16))
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(14)
        .shadow(color: DesignSystem.shadowColor, radius: 6, x: 0, y: 4)
    }
}

// MARK: - Add Trip View (Unchanged)
struct AddTripView: View {
    @Binding var trips: [Trip]
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var startDate = Date()
    @State private var endDate = Date().addingTimeInterval(86400 * 7)
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Trip Details").font(.system(.headline, design: .rounded))) {
                    TextField("Trip Name", text: $name)
                        .font(.system(.body, design: .rounded))
                        .padding(.vertical, 8)
                    DatePicker("Start Date", selection: $startDate, displayedComponents: .date)
                        .font(.system(.body, design: .rounded))
                        .accentColor(DesignSystem.primaryColor)
                    DatePicker("End Date", selection: $endDate, displayedComponents: .date)
                        .font(.system(.body, design: .rounded))
                        .accentColor(DesignSystem.primaryColor)
                }
            }
            .background(DesignSystem.backgroundColor)
            .scrollContentBackground(.hidden)
            .navigationTitle("New Trip")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(.gray)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        let newTrip = Trip(name: name.isEmpty ? "New Trip" : name, startDate: startDate, endDate: endDate)
                        trips.append(newTrip)
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                    .foregroundColor(DesignSystem.primaryColor)
                    .font(.system(.headline, design: .rounded))
                }
            }
        }
    }
}

// MARK: - Explore View (Unchanged)
struct ExploreView: View {
    let cities: [City] = [
        City(name: "Paris", nearbyPlaces: [
            TouristPlace(name: "Eiffel Tower", description: "Iconic Parisian landmark."),
            TouristPlace(name: "Louvre Museum", description: "Home to the Mona Lisa."),
            TouristPlace(name: "Notre-Dame", description: "Gothic cathedral.")
        ], imageName: "paris"),
        City(name: "New York", nearbyPlaces: [
            TouristPlace(name: "Statue of Liberty", description: "Symbol of freedom."),
            TouristPlace(name: "Central Park", description: "Urban oasis."),
            TouristPlace(name: "Times Square", description: "Vibrant hub.")
        ], imageName: "newyork"),
        City(name: "Tokyo", nearbyPlaces: [
            TouristPlace(name: "Shibuya Crossing", description: "Busy crossing."),
            TouristPlace(name: "Tokyo Tower", description: "Observation tower."),
            TouristPlace(name: "Asakusa Temple", description: "Historic temple.")
        ], imageName: "tokyo"),
        City(name: "London", nearbyPlaces: [
            TouristPlace(name: "Big Ben", description: "Iconic clock tower."),
            TouristPlace(name: "Buckingham Palace", description: "Royal residence."),
            TouristPlace(name: "Tower Bridge", description: "Famous bridge.")
        ], imageName: "london"),
        City(name: "Sydney", nearbyPlaces: [
            TouristPlace(name: "Sydney Opera House", description: "Architectural marvel."),
            TouristPlace(name: "Sydney Harbour Bridge", description: "Iconic bridge."),
            TouristPlace(name: "Bondi Beach", description: "Surfing spot.")
        ], imageName: "sydney"),
        City(name: "Rome", nearbyPlaces: [
            TouristPlace(name: "Colosseum", description: "Ancient arena."),
            TouristPlace(name: "Pantheon", description: "Roman temple."),
            TouristPlace(name: "Trevi Fountain", description: "Baroque fountain.")
        ], imageName: "rome")
    ]
    
    var body: some View {
        NavigationView {
            ZStack {
                DesignSystem.backgroundColor.edgesIgnoringSafeArea(.all)
                
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(cities) { city in
                            NavigationLink(destination: CityDetailView(city: city)) {
                                CityCard(city: city)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.horizontal, 16)
                    }
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                }
            }
            .navigationTitle("Explore")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

// MARK: - City Card (Unchanged)
struct CityCard: View {
    let city: City
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Image(city.imageName)
                .resizable()
                .scaledToFill()
                .frame(height: 180)
                .clipped()
                .cornerRadius(16, corners: [.topLeft, .topRight])
            
            VStack(alignment: .leading, spacing: 8) {
                Text(city.name)
                    .font(.system(.title3, design: .rounded, weight: .bold))
                    .foregroundColor(.primary)
                Text("\(city.nearbyPlaces.count) places to explore")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundColor(.secondary)
            }
            .padding(16)
        }
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - City Detail View (Unchanged)
struct CityDetailView: View {
    let city: City
    @State private var selectedPlace: TouristPlace? = nil
    
    var body: some View {
        ZStack {
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(city.nearbyPlaces) { place in
                        PlaceRow(place: place, onInfoTap: {
                            print("Tapping info for \(place.name)")
                            selectedPlace = place
                            print("Selected place set to: \(String(describing: selectedPlace?.name))")
                        })
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.vertical, 20)
            }
            .background(DesignSystem.backgroundColor)
            .navigationTitle(city.name)
            .navigationBarTitleDisplayMode(.large)
            
            if let place = selectedPlace {
                Color.black.opacity(0.3)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        print("Dismissing modal")
                        selectedPlace = nil
                    }
                
                PlaceDetailView(place: place, onAddToTrip: { _ in
                    // Placeholder action for adding to trip
                })
                    .transition(.move(edge: .bottom))
                    .animation(.spring(response: 0.4, dampingFraction: 0.8), value: selectedPlace)
                    .zIndex(1)
            }
        }
        .onAppear {
            print("CityDetailView appeared for \(city.name)")
        }
    }
}

// MARK: - Place Row (Unchanged)
struct PlaceRow: View {
    let place: TouristPlace
    let onInfoTap: () -> Void
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: "mappin.circle.fill")
                .font(.system(size: 24))
                .foregroundColor(DesignSystem.primaryColor)
            Text(place.name)
                .font(.system(.body, design: .rounded, weight: .medium))
                .foregroundColor(.primary)
            Spacer()
            Button(action: {
                print("Info button tapped for \(place.name)")
                onInfoTap()
            }) {
                Image(systemName: "info.circle")
                    .font(.system(size: 20))
                    .foregroundColor(DesignSystem.primaryColor)
            }
        }
        .padding(16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - Place Detail View (Unchanged)
struct PlaceDetailView: View {
    let place: TouristPlace
    let onAddToTrip: (Trip) -> Void
    @State private var selectedTrip: Trip?
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 16) {
            RoundedRectangle(radius: 4, corners: .allCorners)
                .fill(Color.gray.opacity(0.4))
                .frame(width: 40, height: 6)
            
            Text(place.name)
                .font(.system(.headline, design: .rounded, weight: .bold))
                .foregroundColor(.primary)
            
            Text(place.description)
                .font(.system(.body, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            Button(action: {
                if let trip = selectedTrip {
                    onAddToTrip(trip)
                }
            }) {
                Text("Add to Trip")
                    .font(.system(.body, design: .rounded, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 20)
                    .background(DesignSystem.primaryColor)
                    .cornerRadius(14)
            }
        }
        .padding(20)
        .background(DesignSystem.cardGradient)
        .cornerRadius(20)
        .shadow(color: DesignSystem.shadowColor, radius: 10, x: 0, y: 4)
        .frame(maxWidth: .infinity)
        .frame(maxHeight: 250, alignment: .bottom)
        .padding(.horizontal, 20)
        .padding(.bottom, 20)
        .offset(y: UIScreen.main.bounds.height - 300)
    }
}

// MARK: - Trip Detail View (Unchanged)
struct TripDetailView: View {
    @Binding var trip: Trip
    let onAddPlace: (TouristPlace) -> Void
    @State private var selectedSection: TripSection = .overview
    
    enum TripSection: String, CaseIterable {
        case overview = "Overview"
        case itinerary = "Itinerary"
        case checklist = "Checklist"
        case expenses = "Expenses"
        
        var icon: String {
            switch self {
            case .overview: return "info.circle.fill"
            case .itinerary: return "calendar"
            case .checklist: return "checkmark.square.fill"
            case .expenses: return "dollarsign.circle.fill"
            }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(TripSection.allCases, id: \.self) { section in
                            Button(action: { selectedSection = section }) {
                                HStack(spacing: 8) {
                                    Image(systemName: section.icon)
                                        .font(.system(size: 18))
                                        .foregroundColor(DesignSystem.primaryColor)
                                    Text(section.rawValue)
                                        .font(.system(.headline, design: .rounded))
                                }
                                .foregroundColor(selectedSection == section ? DesignSystem.primaryColor : .secondary)
                                .padding(.vertical, 10)
                                .padding(.horizontal, 16)
                                .background(
                                    selectedSection == section ?
                                        DesignSystem.primaryColor.opacity(0.15) :
                                        Color.clear
                                )
                                .cornerRadius(12)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                }
                .background(Color.white.opacity(0.9))
                .shadow(color: DesignSystem.shadowColor, radius: 4, x: 0, y: 2)
                
                ScrollView {
                    LazyVStack(spacing: 20) {
                        switch selectedSection {
                        case .overview:
                            OverviewView(trip: $trip)
                        case .itinerary:
                            ItinerarySection(days: $trip.days)
                        case .checklist:
                            ChecklistSection(items: $trip.checklistItems)
                        case .expenses:
                            ExpensesSection(expenses: $trip.expenses)
                        }
                    }
                    .padding(20)
                }
            }
            .background(DesignSystem.backgroundColor)
            .navigationTitle(trip.name)
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

// MARK: - Overview View (Unchanged)
struct OverviewView: View {
    @Binding var trip: Trip
    
    var tripDuration: Int {
        Calendar.current.dateComponents([.day], from: trip.startDate, to: trip.endDate).day ?? 0
    }
    
    var body: some View {
        VStack(spacing: 20) {
            VStack(spacing: 0) {
                DesignSystem.skyBlue
                    .frame(height: 100)
                    .overlay(
                        HStack {
                            Image(systemName: "airplane")
                                .font(.system(size: 24))
                                .foregroundColor(.white)
                                .padding(.leading, 16)
                            
                            TextField("Trip Name", text: $trip.name)
                                .font(.system(.title, design: .rounded, weight: .bold))
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .submitLabel(.done)
                            
                            Spacer()
                        }
                    )
                
                VStack(spacing: 16) {
                    HStack(spacing: 20) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Start")
                                .font(.system(.subheadline, design: .rounded))
                                .foregroundColor(.secondary)
                            DatePicker("", selection: $trip.startDate, displayedComponents: .date)
                                .labelsHidden()
                                .accentColor(DesignSystem.primaryColor)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 6) {
                            Text("End")
                                .font(.system(.subheadline, design: .rounded))
                                .foregroundColor(.secondary)
                            DatePicker("", selection: $trip.endDate, displayedComponents: .date)
                                .labelsHidden()
                                .accentColor(DesignSystem.primaryColor)
                        }
                    }
                    Text("\(tripDuration) days")
                        .font(.system(.headline, design: .rounded, weight: .bold))
                        .foregroundColor(DesignSystem.primaryColor)
                        .padding(.vertical, 6)
                        .padding(.horizontal, 16)
                        .background(DesignSystem.primaryColor.opacity(0.15))
                        .cornerRadius(14)
                }
                .padding(16)
            }
            .background(DesignSystem.cardGradient)
            .cornerRadius(16)
            .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                StatCard(title: "Days Planned", value: "\(trip.days.count)", icon: "calendar")
                StatCard(
                    title: "Items Checked",
                    value: "\(trip.checklistItems.filter { $0.isChecked }.count)/\(trip.checklistItems.count)",
                    icon: "checkmark.circle.fill"
                )
                StatCard(
                    title: "Total Spent",
                    value: String(format: "$%.2f", trip.expenses.reduce(0) { $0 + $1.amount }),
                    icon: "dollarsign.circle.fill"
                )
            }
        }
    }
}

// MARK: - Stat Card (Unchanged)
struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(DesignSystem.primaryColor)
            Text(value)
                .font(.system(.title3, design: .rounded, weight: .bold))
                .foregroundColor(.primary)
            Text(title)
                .font(.system(.subheadline, design: .rounded))
                .foregroundColor(.secondary)
        }
        .padding(16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - Itinerary Section (Unchanged)
struct ItinerarySection: View {
    @Binding var days: [Day]
    @State private var showingAddDay = false
    
    var body: some View {
        VStack(spacing: 16) {
            ForEach(days.indices, id: \.self) { index in
                NavigationLink(destination: DayDetailView(day: $days[index])) {
                    DayRow(day: days[index])
                }
                .buttonStyle(PlainButtonStyle())
            }
            .onDelete(perform: deleteDay)
            
            Button(action: { showingAddDay = true }) {
                HStack {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(DesignSystem.primaryColor)
                    Text("Add Day")
                }
                .font(.system(.headline, design: .rounded, weight: .bold))
                .foregroundColor(DesignSystem.primaryColor)
                .padding()
                .frame(maxWidth: .infinity)
                .background(DesignSystem.primaryColor.opacity(0.15))
                .cornerRadius(12)
            }
            .sheet(isPresented: $showingAddDay) {
                AddDayView(days: $days)
            }
        }
    }
    
    func deleteDay(at offsets: IndexSet) {
        withAnimation {
            days.remove(atOffsets: offsets)
        }
    }
}

// MARK: - Day Row (Unchanged)
struct DayRow: View {
    let day: Day
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: "map.fill")
                .font(.system(size: 20))
                .foregroundColor(DesignSystem.primaryColor)
            VStack(alignment: .leading, spacing: 6) {
                Text("Day \(day.id)")
                    .font(.system(.headline, design: .rounded, weight: .bold))
                    .foregroundColor(.primary)
                Text(day.place)
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(DesignSystem.primaryColor)
        }
        .padding(16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - Add Day View (Unchanged)
struct AddDayView: View {
    @Binding var days: [Day]
    @Environment(\.dismiss) var dismiss
    @State private var place = ""
    @State private var time = Date()
    @State private var notes = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Day Details").font(.system(.headline, design: .rounded))) {
                    TextField("Place", text: $place)
                        .font(.system(.body, design: .rounded))
                        .padding(.vertical, 8)
                    DatePicker("Time", selection: $time, displayedComponents: [.date, .hourAndMinute])
                        .font(.system(.body, design: .rounded))
                        .accentColor(DesignSystem.primaryColor)
                    TextField("Notes", text: $notes, axis: .vertical)
                        .font(.system(.body, design: .rounded))
                        .lineLimit(3...)
                }
            }
            .background(DesignSystem.backgroundColor)
            .scrollContentBackground(.hidden)
            .navigationTitle("New Day")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(.gray)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        let newDay = Day(id: days.count + 1, place: place.isEmpty ? "New Destination" : place, time: time, notes: notes)
                        days.append(newDay)
                        dismiss()
                    }
                    .disabled(place.trimmingCharacters(in: .whitespaces).isEmpty)
                    .foregroundColor(DesignSystem.primaryColor)
                    .font(.system(.headline, design: .rounded))
                }
            }
        }
    }
}

// MARK: - Day Detail View (Unchanged)
struct DayDetailView: View {
    @Binding var day: Day
    
    var body: some View {
        Form {
            Section(header: Text("Day Details").font(.system(.headline, design: .rounded))) {
                TextField("Place", text: $day.place)
                    .font(.system(.body, design: .rounded))
                    .padding(.vertical, 8)
                DatePicker("Time", selection: $day.time, displayedComponents: [.date, .hourAndMinute])
                    .font(.system(.body, design: .rounded))
                    .accentColor(DesignSystem.primaryColor)
                TextField("Notes", text: $day.notes, axis: .vertical)
                    .font(.system(.body, design: .rounded))
                    .lineLimit(3...)
            }
        }
        .background(DesignSystem.backgroundColor)
        .scrollContentBackground(.hidden)
        .navigationTitle("Day \(day.id)")
    }
}

// MARK: - Checklist Section (Unchanged)
struct ChecklistSection: View {
    @Binding var items: [ChecklistItem]
    @State private var newItem = ""
    
    var body: some View {
        VStack(spacing: 16) {
            ForEach(items.indices, id: \.self) { index in
                ChecklistRow(item: $items[index])
            }
            .onDelete(perform: deleteItem)
            
            HStack(spacing: 12) {
                TextField("New Item", text: $newItem)
                    .font(.system(.body, design: .rounded))
                    .padding(12)
                    .background(DesignSystem.cardGradient)
                    .cornerRadius(12)
                    .shadow(color: DesignSystem.shadowColor, radius: 4, x: 0, y: 2)
                
                Button(action: { addItem() }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(DesignSystem.primaryColor)
                }
                .disabled(newItem.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
    
    func addItem() {
        if !newItem.trimmingCharacters(in: .whitespaces).isEmpty {
            withAnimation(.spring()) {
                items.append(ChecklistItem(name: newItem, isChecked: false))
                newItem = ""
            }
        }
    }
    
    func deleteItem(at offsets: IndexSet) {
        withAnimation {
            items.remove(atOffsets: offsets)
        }
    }
}

// MARK: - Checklist Row (Unchanged)
struct ChecklistRow: View {
    @Binding var item: ChecklistItem
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: item.isChecked ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 24))
                .foregroundColor(item.isChecked ? DesignSystem.primaryColor : .secondary)
                .onTapGesture {
                    withAnimation(.spring()) {
                        item.isChecked.toggle()
                    }
                }
            Text(item.name)
                .font(.system(.body, design: .rounded, weight: .medium))
                .foregroundColor(.primary)
        }
        .padding(16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - Expenses Section (Unchanged)
struct ExpensesSection: View {
    @Binding var expenses: [Expense]
    @State private var newAmount = ""
    @State private var newCategory = ""
    
    var totalSpent: Double {
        expenses.reduce(0) { $0 + $1.amount }
    }
    
    var body: some View {
        VStack(spacing: 16) {
            VStack(spacing: 10) {
                Text("Total Spent")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundColor(.secondary)
                Text("$\(totalSpent, specifier: "%.2f")")
                    .font(.system(.title2, design: .rounded, weight: .bold))
                    .foregroundColor(DesignSystem.primaryColor)
            }
            .padding(16)
            .frame(maxWidth: .infinity)
            .background(DesignSystem.cardGradient)
            .cornerRadius(16)
            .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
            
            ForEach(expenses.indices, id: \.self) { index in
                ExpenseRow(expense: expenses[index])
            }
            .onDelete(perform: deleteExpense)
            
            HStack(spacing: 12) {
                TextField("Amount", text: $newAmount)
                    .font(.system(.body, design: .rounded))
                    .keyboardType(.decimalPad)
                    .padding(12)
                    .background(DesignSystem.cardGradient)
                    .cornerRadius(12)
                    .shadow(color: DesignSystem.shadowColor, radius: 4, x: 0, y: 2)
                
                TextField("Category", text: $newCategory)
                    .font(.system(.body, design: .rounded))
                    .padding(12)
                    .background(DesignSystem.cardGradient)
                    .cornerRadius(12)
                    .shadow(color: DesignSystem.shadowColor, radius: 4, x: 0, y: 2)
                
                Button(action: { addExpense() }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(DesignSystem.primaryColor)
                }
                .disabled(newAmount.isEmpty || newCategory.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
    
    func addExpense() {
        if let amount = Double(newAmount), !newCategory.trimmingCharacters(in: .whitespaces).isEmpty {
            withAnimation(.spring()) {
                expenses.append(Expense(amount: amount, category: newCategory, date: Date()))
                newAmount = ""
                newCategory = ""
            }
        }
    }
    
    func deleteExpense(at offsets: IndexSet) {
        withAnimation {
            expenses.remove(atOffsets: offsets)
        }
    }
}

// MARK: - Expense Row (Unchanged)
struct ExpenseRow: View {
    let expense: Expense
    
    var body: some View {
        HStack(spacing: 12) {
            Text(expense.category)
                .font(.system(.body, design: .rounded, weight: .medium))
                .foregroundColor(.primary)
            Spacer()
            Text("$\(expense.amount, specifier: "%.2f")")
                .font(.system(.body, design: .rounded, weight: .bold))
                .foregroundColor(DesignSystem.primaryColor)
        }
        .padding(16)
        .background(DesignSystem.cardGradient)
        .cornerRadius(16)
        .shadow(color: DesignSystem.shadowColor, radius: 8, x: 0, y: 4)
    }
}

// MARK: - Hex Color Extension
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "#", with: "")
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 6:
            (a, r, g, b) = (255, (int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - Custom Corner Radius Extension
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedRectangle(radius: radius, corners: corners))
    }
}

struct RoundedRectangle: Shape {
    var radius: CGFloat
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// MARK: - Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
